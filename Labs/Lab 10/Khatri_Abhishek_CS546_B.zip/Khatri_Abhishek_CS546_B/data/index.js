const usersData = require("./users");

module.exports = {
	usersData,
};
